
async function searchSong() {
  const query = document.getElementById("searchInput").value;
  const resultsDiv = document.getElementById("results");
  resultsDiv.innerHTML = "⏳ Qidirilmoqda...";

  const url = `https://itunes.apple.com/search?term=${encodeURIComponent(query)}&entity=song&limit=5`;

  try {
    const response = await fetch(url);
    const data = await response.json();
    resultsDiv.innerHTML = "";

    if (data.results.length === 0) {
      resultsDiv.innerHTML = "😔 Qo‘shiq topilmadi.";
    } else {
      data.results.forEach(song => {
        const songDiv = document.createElement("div");
        songDiv.className = "song";
        songDiv.innerHTML = `
          <strong>${song.trackName}</strong> - ${song.artistName}<br/>
          <audio controls src="${song.previewUrl}"></audio>
        `;
        resultsDiv.appendChild(songDiv);
      });
    }
  } catch (error) {
    resultsDiv.innerHTML = "⚠️ Xatolik yuz berdi. Qayta urinib ko‘ring.";
  }
}
